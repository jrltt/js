<?php
	mysql_close($conn);
?>

